# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from flask import Flask, render_template, request, session
import pandas as pd
from SERP_Data import *
import sys
import os

app = Flask(__name__)

app.secret_key = 'secret'
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SNED_FILE_MAX_AGE_DEAFULT'] = 0

sys.path.append(os.path.abspath('../'))

@app.route('/')
@app.route('/input')
def input() -> 'html':
    session.clear()
    return render_template('flaskInput.html', the_title = 'Welcome!')

@app.route('/search', methods = ['GET', 'POST'])
def search() -> 'html':
    session.clear()
    links = request.form['links']
    title = "Processing..."
    global names
    names = []
    link_list = links.strip().split(', ')
    for link in link_list:
        parts = link.strip().split('/')
        sub = parts[5].strip().split('?')
        i_d = sub[0]
        title = collection(i_d)
        names.append(title)

    return render_template('flaskProcess.html', the_title = title, ids = names)

@app.route('/process', methods = ['GET', 'POST'])
def edit() -> 'html':
    name = session.get('name', None)
    group = session.get('group', None)
    
    if not name:
        session['name'] = request.form['name']
        session['group'] = request.form['group']
        name = session['name']
        group = session['group']
    global result, result_rt
    result, result_rt = process(names, name, group)
    result = process_text(result)
    return render_template('flaskLoading.html', items = result,)


@app.route('/tmodel', methods = ['GET', 'POST'])
def topics() -> 'html':
    sku = request.form['sku']
    rcls = request.form['rcls']
    vtz = request.form['vtz']
    query = request.form['query']

    links = topic_model(result, result_rt, sku, rcls, vtz, query)
    tags = ['Distribution of Topics']
    for l in range(1, len(links) - 1):
        tag = links[l].strip().split("_")
        t = "Topic " + " " + tag[2][5]
        tags.append(t)
    tags.append('Search Terms Distribution')
    return render_template('flaskResults.html', links = links, tags = tags,)


@app.route('/clr', methods = ['GET', 'POST'])
def clr() -> 'html':
    session.clear()
    return render_template('flaskInput.html', the_title = 'Welcome!')

@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = '0'
    response.headers['Cache-Control'] = 'public, max-age=0'
    return response


app.run(debug = True)
